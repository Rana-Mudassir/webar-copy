const mongoose = require('mongoose');
const Scehma = mongoose.Schema;

const ProductScehma = new Scehma(
    {
    productId : {
        type: String,
        unique: true
    },
    productName : {
        type: String,
        required: true
    },
    productDesc: {
        type: String,
        required: true
    },
    productImageUrl: {
        type : String,
        required: true
    },
    productPrice:{
        type: Number,
        required: true
    },
    categories: {
        type: [String],
        enum: [ 'Men-Shoes', 'Kids-Shoes', 'Formal-Shoes', 'Outdoor-Shoes']
    },

}, {timestamps: true}
);

module.exports = mongoose.model('Product', ProductScehma, 'product');