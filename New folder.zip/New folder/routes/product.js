const express = require('express');
const router = express.Router();

const Product = require('../controllers/Product');

// router.get('/', Product.index);
// router.get('/show', Product.show);
// router.post('/newPrd', Product.newPrd);
// router.put('/updatePrd', Product.updatePrd);
// router.delete('/deletePrd', Product.dltProd);
// router.get('/productListing', Product.productListing);

router.get('/', Product.index);
router.get('/product/:id', Product.show);
router.post('/product', Product.newPrd);
router.put('/product', Product.updatePrd);
router.delete('/product/:id', Product.dltProd);
router.get('/product/listing', Product.productListing);

module.exports= router;